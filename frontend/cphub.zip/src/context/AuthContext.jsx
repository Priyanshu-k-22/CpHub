import React, {
    createContext,
    useContext,
    useEffect,
    useState,
} from "react";

import {
    getCurrentUser,
    logoutUser,
} from "../api/auth.api";


const AuthContext = createContext(null);


/*
|--------------------------------------------------------------------------
| Auth Provider
|--------------------------------------------------------------------------
*/

export const AuthProvider = ({ children }) => {

    const [user, setUser] = useState(null);

    const [loading, setLoading] = useState(true);


    /*
    |--------------------------------------------------------------------------
    | Check Existing Session
    |--------------------------------------------------------------------------
    |
    | Called when the application starts.
    |
    | If the browser already has the accessToken cookie,
    | backend returns the current user.
    |
    */

    const checkAuth = async () => {

        try {

            const response =
                await getCurrentUser();

            setUser(response.data);

        } catch (error) {

            setUser(null);

        } finally {

            setLoading(false);

        }
    };


    /*
    |--------------------------------------------------------------------------
    | Login
    |--------------------------------------------------------------------------
    |
    | Login API already returns the user.
    |
    | We DO NOT call /auth/me here.
    |
    */

    const login = (userData) => {

        setUser(userData);

        setLoading(false);
    };


    /*
    |--------------------------------------------------------------------------
    | Logout
    |--------------------------------------------------------------------------
    */

    const logout = async () => {

        try {

            await logoutUser();

        } catch (error) {

            console.error(
                "Logout failed:",
                error.response?.data || error
            );

        } finally {

            setUser(null);

            setLoading(false);
        }
    };


    /*
    |--------------------------------------------------------------------------
    | Initial Authentication Check
    |--------------------------------------------------------------------------
    */

    useEffect(() => {

        checkAuth();

    }, []);


    return (
        <AuthContext.Provider
            value={{
                user,
                loading,

                isAuthenticated: !!user,

                login,
                logout,
                checkAuth,
            }}
        >
            {children}
        </AuthContext.Provider>
    );
};


/*
|--------------------------------------------------------------------------
| useAuth Hook
|--------------------------------------------------------------------------
*/

export const useAuth = () => {

    const context = useContext(
        AuthContext
    );

    if (!context) {

        throw new Error(
            "useAuth must be used inside AuthProvider"
        );
    }

    return context;
};