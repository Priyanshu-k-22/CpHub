import React from "react";
import {
    BrowserRouter,
    Routes,
    Route,
} from "react-router-dom";

import Home from "./pages/Home.jsx";
import About from "./pages/About.jsx";
import Events from "./pages/Events.jsx";
import Contests from "./pages/Contests.jsx";
import Leaderboard from "./pages/Leaderboard.jsx";
import Team from "./pages/Team.jsx";
import Achievements from "./pages/Achievements.jsx";
import Gallery from "./pages/Gallery.jsx";
import Problems from "./pages/Problems.jsx";
import ProblemDetails from "./pages/ProblemDetails.jsx";
import ProblemHistory from "./pages/ProblemHistory.jsx";

import Login from "./components/auth/Login.jsx";
import Register from "./components/auth/Register.jsx";
import UserDashboard from "./components/dashboard/UserDashboard.jsx";
import ProtectedRoute from "./components/auth/ProtectedRoute.jsx";

import { AuthProvider } from "./context/AuthContext.jsx";


export default function App() {

    return (
        <BrowserRouter>

            <AuthProvider>

                <Routes>

                    {/* =====================================================
                        PUBLIC PAGES
                    ===================================================== */}

                    <Route
                        path="/"
                        element={<Home />}
                    />

                    <Route
                        path="/about"
                        element={<About />}
                    />

                    <Route
                        path="/events"
                        element={<Events />}
                    />

                    <Route
                        path="/contests"
                        element={<Contests />}
                    />

                    <Route
                        path="/leaderboard"
                        element={<Leaderboard />}
                    />

                    <Route
                        path="/team"
                        element={<Team />}
                    />

                    <Route
                        path="/achievements"
                        element={<Achievements />}
                    />

                    <Route
                        path="/gallery"
                        element={<Gallery />}
                    />


                    {/* =====================================================
                        AUTHENTICATION
                    ===================================================== */}

                    <Route
                        path="/login"
                        element={<Login />}
                    />

                    <Route
                        path="/register"
                        element={<Register />}
                    />


                    {/* =====================================================
                        PROTECTED PAGES
                    ===================================================== */}

                    <Route element={<ProtectedRoute />}>

                        {/* Dashboard */}

                        <Route
                            path="/dashboard"
                            element={<UserDashboard />}
                        />


                        {/* Problems */}

                        <Route
                            path="/problems"
                            element={<Problems />}
                        />


                        {/* Problem History */}

                        <Route
                            path="/problems/history"
                            element={<ProblemHistory />}
                        />


                        {/* Problem Details */}

                        <Route
                            path="/problems/:id"
                            element={<ProblemDetails />}
                        />

                    </Route>

                </Routes>

            </AuthProvider>

        </BrowserRouter>
    );
}