import api from "./api";


/*
|--------------------------------------------------------------------------
| Register
|--------------------------------------------------------------------------
*/

export const registerUser = async ({
    username,
    email,
    password,
}) => {

    const response = await api.post(
        "/auth/register",
        {
            username,
            email,
            password,
        }
    );

    return response.data;
};


/*
|--------------------------------------------------------------------------
| Login
|--------------------------------------------------------------------------
*/

export const loginUser = async ({
    email,
    password,
}) => {

    const response = await api.post(
        "/auth/login",
        {
            email,
            password,
        }
    );

    return response.data;
};


/*
|--------------------------------------------------------------------------
| Get Current User
|--------------------------------------------------------------------------
*/

export const getCurrentUser = async () => {

    const response = await api.get(
        "/auth/me"
    );

    return response.data;
};


/*
|--------------------------------------------------------------------------
| Logout
|--------------------------------------------------------------------------
*/

export const logoutUser = async () => {

    const response = await api.post(
        "/auth/logout"
    );

    return response.data;
};