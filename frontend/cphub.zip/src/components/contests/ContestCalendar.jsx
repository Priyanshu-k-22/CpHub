import { useEffect, useMemo, useState } from "react";

import { getContests } from "../../api/contestApi";


const PLATFORM_ICONS = {
    Codeforces: "CF",
    CodeChef: "CC",
    AtCoder: "AC",
    LeetCode: "LC"
};


const CATEGORY_OPTIONS = [
    {
        label: "All",
        value: ""
    },
    {
        label: "CP",
        value: "CP"
    },
    {
        label: "DSA",
        value: "DSA"
    }
];


const getMonthStart = (date) => {
    return new Date(
        date.getFullYear(),
        date.getMonth(),
        1
    );
};


const getCalendarDays = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth();

    const firstDay = new Date(
        year,
        month,
        1
    );

    const firstDayOfWeek =
        firstDay.getDay();

    const daysInMonth =
        new Date(
            year,
            month + 1,
            0
        ).getDate();

    const previousMonthDays =
        new Date(
            year,
            month,
            0
        ).getDate();

    const days = [];

    /*
     * Previous month's trailing days
     */
    for (
        let i = firstDayOfWeek - 1;
        i >= 0;
        i--
    ) {
        days.push({
            date: new Date(
                year,
                month - 1,
                previousMonthDays - i
            ),
            currentMonth: false
        });
    }


    /*
     * Current month
     */
    for (
        let day = 1;
        day <= daysInMonth;
        day++
    ) {
        days.push({
            date: new Date(
                year,
                month,
                day
            ),
            currentMonth: true
        });
    }


    /*
     * Next month's leading days
     */
    let nextDay = 1;

    while (days.length % 7 !== 0) {
        days.push({
            date: new Date(
                year,
                month + 1,
                nextDay
            ),
            currentMonth: false
        });

        nextDay++;
    }

    return days;
};


const getDateKey = (date) => {
    return [
        date.getFullYear(),
        String(date.getMonth() + 1)
            .padStart(2, "0"),
        String(date.getDate())
            .padStart(2, "0")
    ].join("-");
};


const formatTime = (dateString) => {
    return new Intl.DateTimeFormat(
        "en-IN",
        {
            hour: "numeric",
            minute: "2-digit",
            hour12: true,
            timeZone: "Asia/Kolkata"
        }
    ).format(
        new Date(dateString)
    );
};


const formatMonth = (date) => {
    return new Intl.DateTimeFormat(
        "en-IN",
        {
            month: "long",
            year: "numeric"
        }
    ).format(date);
};


const ContestCalendar = () => {

    const [currentDate, setCurrentDate] =
        useState(
            getMonthStart(new Date())
        );

    const [category, setCategory] =
        useState("");

    const [contests, setContests] =
        useState([]);

    const [loading, setLoading] =
        useState(true);

    const [error, setError] =
        useState("");


    /*
     * Fetch contests
     */
    useEffect(() => {
        const fetchContests = async () => {
            try {
                setLoading(true);
                setError("");

                const response =
                    await getContests({
                        category
                    });

                setContests(
                    response.data || []
                );
            } catch (error) {
                console.error(
                    "Failed to fetch contests:",
                    error
                );

                setError(
                    "Unable to load contests."
                );
            } finally {
                setLoading(false);
            }
        };

        fetchContests();
    }, [category]);


    /*
     * Calendar days
     */
    const calendarDays = useMemo(
        () =>
            getCalendarDays(
                currentDate
            ),
        [currentDate]
    );


    /*
     * Group contests by date
     */
    const contestsByDate = useMemo(() => {

        const grouped = {};

        contests.forEach((contest) => {
            const date = new Date(
                contest.startTime
            );

            const key =
                getDateKey(date);

            if (!grouped[key]) {
                grouped[key] = [];
            }

            grouped[key].push(
                contest
            );
        });

        return grouped;

    }, [contests]);


    const previousMonth = () => {
        setCurrentDate(
            (previous) =>
                new Date(
                    previous.getFullYear(),
                    previous.getMonth() - 1,
                    1
                )
        );
    };


    const nextMonth = () => {
        setCurrentDate(
            (previous) =>
                new Date(
                    previous.getFullYear(),
                    previous.getMonth() + 1,
                    1
                )
        );
    };


    const goToToday = () => {
        setCurrentDate(
            getMonthStart(new Date())
        );
    };


    return (
        <section className="w-full">

            {/* Header */}
            <div className="mb-8 flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">

                <div>
                    <p className="mb-2 font-mono text-xs uppercase tracking-[0.25em] text-[#4affc4]">
                        Contest Calendar
                    </p>

                    <h1 className="text-3xl font-semibold text-[#edf2f7] md:text-4xl">
                        Upcoming Contests
                    </h1>

                    <p className="mt-2 max-w-2xl text-sm text-[#aeb9c7]">
                        Keep track of upcoming CP and DSA contests
                        across popular platforms.
                    </p>
                </div>


                {/* Category filter */}
                <div className="flex gap-2 rounded-xl border border-[#1c2734] bg-[#0a1018] p-1">

                    {CATEGORY_OPTIONS.map(
                        (option) => (
                            <button
                                key={
                                    option.value ||
                                    "all"
                                }
                                type="button"
                                onClick={() =>
                                    setCategory(
                                        option.value
                                    )
                                }
                                className={`rounded-lg px-4 py-2 text-sm transition ${
                                    category ===
                                    option.value
                                        ? "bg-[#4affc4] text-[#060a10]"
                                        : "text-[#aeb9c7] hover:bg-[#111923] hover:text-[#edf2f7]"
                                }`}
                            >
                                {option.label}
                            </button>
                        )
                    )}

                </div>

            </div>


            {/* Calendar controls */}
            <div className="mb-4 flex items-center justify-between">

                <button
                    type="button"
                    onClick={previousMonth}
                    className="rounded-lg border border-[#1c2734] px-3 py-2 text-[#aeb9c7] transition hover:border-[#4affc4] hover:text-[#4affc4]"
                >
                    ←
                </button>


                <div className="flex items-center gap-4">

                    <h2 className="text-lg font-medium text-[#edf2f7]">
                        {formatMonth(
                            currentDate
                        )}
                    </h2>

                    <button
                        type="button"
                        onClick={goToToday}
                        className="rounded-lg border border-[#1c2734] px-3 py-1.5 text-xs text-[#aeb9c7] transition hover:border-[#4affc4] hover:text-[#4affc4]"
                    >
                        Today
                    </button>

                </div>


                <button
                    type="button"
                    onClick={nextMonth}
                    className="rounded-lg border border-[#1c2734] px-3 py-2 text-[#aeb9c7] transition hover:border-[#4affc4] hover:text-[#4affc4]"
                >
                    →
                </button>

            </div>


            {/* Error */}
            {error && (
                <div className="mb-4 rounded-xl border border-red-500/20 bg-red-500/5 p-4 text-sm text-red-400">
                    {error}
                </div>
            )}


            {/* Calendar */}
            <div className="overflow-hidden rounded-2xl border border-[#1c2734] bg-[#080d14]">

                {/* Weekdays */}
                <div className="grid grid-cols-7 border-b border-[#1c2734]">

                    {[
                        "Sun",
                        "Mon",
                        "Tue",
                        "Wed",
                        "Thu",
                        "Fri",
                        "Sat"
                    ].map(
                        (day) => (
                            <div
                                key={day}
                                className="border-r border-[#1c2734] px-2 py-3 text-center font-mono text-[11px] uppercase tracking-wider text-[#556275] last:border-r-0"
                            >
                                {day}
                            </div>
                        )
                    )}

                </div>


                {/* Days */}
                {loading ? (

                    <div className="flex min-h-[500px] items-center justify-center text-sm text-[#556275]">
                        Loading contests...
                    </div>

                ) : (

                    <div className="grid grid-cols-7">

                        {calendarDays.map(
                            ({
                                date,
                                currentMonth
                            }) => {

                                const key =
                                    getDateKey(
                                        date
                                    );

                                const dayContests =
                                    contestsByDate[
                                        key
                                    ] || [];

                                const isToday =
                                    getDateKey(
                                        date
                                    ) ===
                                    getDateKey(
                                        new Date()
                                    );

                                return (
                                    <div
                                        key={key}
                                        className={`min-h-[130px] border-b border-r border-[#1c2734] p-2 ${
                                            currentMonth
                                                ? "bg-[#080d14]"
                                                : "bg-[#060a10]/60"
                                        }`}
                                    >

                                        {/* Date */}
                                        <div className="mb-2 flex justify-end">

                                            <span
                                                className={`flex h-7 w-7 items-center justify-center rounded-full text-xs ${
                                                    isToday
                                                        ? "bg-[#4affc4] font-semibold text-[#060a10]"
                                                        : currentMonth
                                                        ? "text-[#aeb9c7]"
                                                        : "text-[#3e4a59]"
                                                }`}
                                            >
                                                {
                                                    date.getDate()
                                                }
                                            </span>

                                        </div>


                                        {/* Contests */}
                                        <div className="space-y-1.5">

                                            {dayContests.map(
                                                (
                                                    contest,
                                                    index
                                                ) => (
                                                    <a
                                                        key={`${contest.platform}-${contest.name}-${index}`}
                                                        href={
                                                            contest.externalLink
                                                        }
                                                        target="_blank"
                                                        rel="noreferrer"
                                                        className="block rounded-lg border border-[#1c2734] bg-[#0d141d] p-2 transition hover:border-[#4affc4]/50 hover:bg-[#111b25]"
                                                    >

                                                        <div className="flex items-center gap-1.5">

                                                            <span className="flex h-5 w-5 shrink-0 items-center justify-center rounded bg-[#111923] font-mono text-[8px] font-bold text-[#4affc4]">
                                                                {
                                                                    PLATFORM_ICONS[
                                                                        contest.platform
                                                                    ]
                                                                }
                                                            </span>

                                                            <span className="truncate text-[10px] font-medium text-[#edf2f7]">
                                                                {
                                                                    contest.name
                                                                }
                                                            </span>

                                                        </div>


                                                        <div className="mt-1 text-[9px] text-[#556275]">
                                                            {
                                                                formatTime(
                                                                    contest.startTime
                                                                )
                                                            }
                                                        </div>

                                                    </a>
                                                )
                                            )}

                                        </div>

                                    </div>
                                );
                            }
                        )}

                    </div>

                )}

            </div>

        </section>
    );
};


export default ContestCalendar;